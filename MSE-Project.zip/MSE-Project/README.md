# MSE-Project
for running the carla, first run environment.py and then in a separate  command windows run platoon_carla.py
